# CarBikeDekho - Detailed Implementation Prompts (Continuation)

---

## 📝 CURSOR PROMPT: COMPREHENSIVE FEATURES (ALL-IN-ONE)

**For maximum efficiency, use this master prompt to build multiple features:**

```
You are building a comprehensive automotive marketplace platform for CarBikeDekho.

PROJECT: CarBikeDekho - Complete Automotive Marketplace (Cars & Bikes)
SCOPE: Implement advanced features to compete with CarDekho, Cars24, CarWale, OLX
TECH: Next.js 14, React 19, TypeScript, Prisma, Supabase

COMPETITIVE FEATURES TO IMPLEMENT (FROM EXISTING PLATFORMS):

## A. ADVANCED SEARCH & DISCOVERY

1. SMART FILTERS:
   - Price range slider (with auto-suggestions: "Under 5L", "5-10L", etc.)
   - Year range slider
   - Mileage range slider
   - Fuel type multi-select (Petrol, Diesel, CNG, Electric, Hybrid)
   - Transmission (Manual, Automatic)
   - Body type (Car types: Sedan, SUV, Hatchback, etc. | Bike types: Sports, Cruiser, etc.)
   - Owner type (1st, 2nd, 3rd, etc.)
   - Location with distance radius (10km, 25km, 50km)
   - Insurance valid/invalid toggle
   - Accident history filter
   - City/region multi-select
   - Seller type (Individual, Dealer)
   - Vehicle condition (Excellent, Good, Fair, Poor)
   
2. SEARCH ENHANCEMENTS:
   - Search history (saved last 10 searches)
   - Popular searches widget (trending searches in user's region)
   - Search suggestions (auto-complete)
   - Recently added filter (last 24h, 7 days)
   - Trending vehicles (most viewed, most liked)
   - Recently saved searches
   - Notifications for saved searches (new listings matching)
   - Budget-based quick filters ("Under ₹3L", "3-5L", etc.)

3. LISTING SORTING:
   - Relevance
   - Price (Low to High, High to Low)
   - Newest First
   - Most Popular
   - Mileage (Low to High)
   - Year (Newest First)
   - Closest to Me
   - Just Listed
   - Most Views

## B. ENHANCED LISTING DETAILS

1. IMAGE GALLERY:
   - Up to 30 high-resolution photos
   - 360-degree view (if available)
   - Video tour (1-3 videos)
   - Auto-arranged (exterior, interior, engine, documents)
   - Image annotations (pointing out features/damage)
   - Zoom capability
   - Thumbnail grid
   - Download capability
   - Share individual photos

2. DETAILED SPECIFICATIONS:
   - Basic: Brand, Model, Year, Trim/Variant
   - Technical: Engine CC, Power (BHP), Torque (Nm), Transmission, Fuel Type
   - Performance: 0-100 time (if available)
   - Dimensions: Length, Width, Height, Wheelbase
   - Capacity: Fuel tank, Boot space, Seating
   - Features: Detailed list (50+ possible)
   - Safety: Airbags, ABS, ESP, etc.
   - Technology: Infotainment, Navigation, Connectivity
   - Ownership: Owner type, Years owned, Usage type
   - Maintenance: Service history, Last service date, Service cost estimate
   - Insurance: Current status, Valid till, Claim history
   - Pollution: Certificate status, Valid till
   - Accident History: Yes/No/Minor, Description, Impact on value

3. PRICE ANALYTICS:
   - Average market price for this model in region
   - Price history (last 30, 60, 90 days)
   - Seller's pricing vs market
   - "Fair price" badge (if within market range)
   - Price comparison with similar listings
   - Price trend line chart

4. DOCUMENTS SECTION:
   - RC (Registration Certificate)
   - Insurance document
   - Pollution certificate
   - Service records
   - Ownership transfer documents (if applicable)
   - Loan status document (if financed)
   - Invoice/Purchase document (if available)
   - Accident/repair report (if available)
   - All documents should be downloadable

5. SELLER INFORMATION:
   - Seller name, rating, reviews count
   - Verification badges (phone, email, ID, PAN, GST)
   - Trust score (calculated from reviews, response time, successful sales)
   - "Member since" date
   - Average response time
   - Total listings (current + historical)
   - Sold vehicles count
   - Other active listings (show 3-5)
   - Seller reviews/testimonials (latest 5)
   - Response rating chart

6. INSPECTION & CERTIFICATION:
   - If vehicle has inspection: Show inspection badge
   - Inspection partner name
   - Inspection date
   - Detailed inspection report (if available)
   - Inspection photos (separate from listing photos)
   - Defects identified and costing
   - Warranty information

## C. COMPARISON FEATURES

1. COMPARISON INTERFACE:
   - Compare up to 4 listings (add via checkbox)
   - Side-by-side display
   - Horizontal scroll on mobile
   - Highlight differences (color-coded)
   - Similar specs shown same color
   - Different specs highlighted

2. COMPARISON DATA:
   - All specs in organized sections
   - Features checklist (✓ has, ✗ doesn't have)
   - Price comparison with difference amount
   - Mileage/km comparison
   - Age comparison
   - Feature count comparison
   - Safety features comparison

3. COMPARISON VISUALIZATIONS:
   - Radar chart (specs visualization)
   - Bar chart (price comparison)
   - Feature heatmap
   - Timeline (vehicle age)

4. COMPARISON ACTIONS:
   - Download as PDF
   - Share comparison link
   - Email comparison
   - Add more listings to comparison
   - Remove listing
   - View full listing for each
   - Contact seller (all in one go)

## D. ENHANCED MESSAGING & CHAT

1. IN-APP MESSAGING:
   - Real-time chat (not phone calls)
   - Message history
   - Typing indicators
   - Read receipts (optional)
   - Auto-suggestions (quick reply templates)
   - FAQ suggestions

2. AUTO-SUGGESTED MESSAGES:
   For Buyers:
   - "Is this vehicle still available?"
   - "Can I book a test drive?"
   - "What's the lowest price you can go?"
   - "Can you do a home inspection?"
   - "Is there any pending finance?"
   
   For Sellers:
   - "When are you available for viewing?"
   - "Vehicle inspection available?"
   - "Financing available?"
   - "Delivery available?"

3. NOTIFICATION SYSTEM:
   - New inquiry notification
   - Message notification
   - Negotiation counter-offer
   - Listing expiry reminder (48h, 24h)
   - New similar listing alert (for saved searches)
   - Price drop notification

## E. PAYMENT & TRANSACTION

1. SECURE PAYMENT GATEWAY:
   - Multiple payment options (Card, UPI, Wallet, Bank Transfer)
   - Razorpay/Instamojo integration
   - Payment confirmation
   - Receipt generation
   - Invoice PDF

2. ESCROW SYSTEM (Optional premium):
   - Buyer pays platform (not seller)
   - Release conditions:
     * Both parties agree
     * Documents transferred
     * Inspection passed (if opted)
   - Dispute resolution
   - Refund policy

3. TRANSACTION TRACKING:
   - Transaction status (Initiated, Processing, Completed, Disputed)
   - Timeline view
   - Document checklist
   - Release status

## F. REVIEWS & RATINGS SYSTEM

1. SELLER REVIEWS:
   - 5-star rating system
   - Review categories:
     * Communication (was seller responsive?)
     * Vehicle condition (as described?)
     * Price fairness (good value for money?)
     * Transaction smoothness (easy process?)
     * Honesty & transparency
   - Written review (optional)
   - Helpful/Unhelpful voting
   - Verified buyer badge (bought from this seller)
   - Review moderation (flag inappropriate)

2. SELLER PROFILE:
   - Average rating
   - Rating distribution (% for each star)
   - Total reviews
   - Response rate %
   - Average response time
   - Member since
   - Total successful transactions

3. REVIEW FEATURES:
   - Seller can respond to reviews
   - Review sorting (newest, highest, lowest, most helpful)
   - Report inappropriate review
   - Only verified buyers can review

## G. WISHLIST & ALERTS

1. WISHLIST:
   - Save listings
   - Organize into collections
   - Notes for each listing
   - Comparison list
   - Price alert for each
   - Share wishlist
   - Export wishlist

2. PRICE ALERTS:
   - Set maximum price for each listing
   - Notification when price drops below alert
   - Email & in-app notification
   - Alert history
   - Modify alerts anytime

3. SAVED SEARCHES:
   - Save frequently used filter combinations
   - Name your saved searches
   - Auto-notify when new listings match
   - Frequency (daily, weekly, never)
   - View results of saved search

## H. VEHICLE ANALYTICS & INSIGHTS

1. PRICE ANALYTICS:
   - Historical price data (line chart)
   - Average price for model in region
   - Price range (lowest, average, highest)
   - Price by year (depreciation curve)
   - Price by mileage
   - Price by owner type
   - Seasonal price trends

2. MARKET INTELLIGENCE:
   - "Best time to buy" recommendation
   - Depreciation rate for model
   - "Similar cars in your area" with prices
   - Price history of this specific vehicle (if available)
   - Market demand indicator (high/medium/low)

3. ANALYTICS FOR SELLERS:
   - Views per day (chart)
   - Inquiries per day (chart)
   - Geographic distribution of inquiries
   - Average time to first inquiry
   - View to inquiry conversion rate
   - Comparison: how your pricing compares to market
   - Recommendations: "Lower price to ₹X to attract more buyers"

## I. SPECIAL BADGES & TRUST INDICATORS

BUYER TRUST BADGES:
- "Verified listing" (all documents uploaded)
- "Inspected" (passed third-party inspection)
- "Trust verified seller" (high rating, many transactions)
- "Certified" (from certified dealer)
- "Insurance valid" (current insurance status)
- "Pollution valid" (current pollution certificate)
- "All documents" (RC, insurance, service records uploaded)

SELLER TRUST BADGES:
- "Verified phone" (OTP verified)
- "Verified email"
- "Verified identity" (ID verified)
- "Trusted seller" (100+ ratings, >4 stars)
- "Super seller" (10+ successful transactions)
- "Response master" (avg response <30 min)
- "Transparent seller" (all documents uploaded)

## J. ADDITIONAL FUNCTIONALITY

1. FINANCING CALCULATOR:
   - EMI calculator (enter loan amount, tenure, rate)
   - Loan eligibility calculator
   - Down payment calculator
   - Insurance included in EMI
   - Maintenance cost estimation

2. INSURANCE INTEGRATION:
   - Insurance premium quote
   - Compare insurance plans
   - Coverage recommendations
   - Online insurance purchase (if integrated)

3. LOCATION SERVICES:
   - Dealer locator (authorized service centers)
   - Test drive location options
   - Delivery/pickup location
   - Distance to vehicle

4. MOBILE RESPONSIVE:
   - All features available on mobile
   - Touch-friendly interface
   - Bottom navigation
   - Quick actions
   - Mobile-specific optimizations

## K. CONTENT & INFORMATION

1. BUYING GUIDE:
   - How to buy used cars
   - Things to check before buying
   - Common mistakes to avoid
   - Negotiation tips
   - Financing options explained
   - Insurance requirements

2. VEHICLE INFORMATION:
   - Brand history
   - Model specifications
   - Common issues for model
   - Ownership cost calculator
   - Maintenance schedule
   - Service cost trends

3. EXPERT REVIEWS:
   - Professional vehicle reviews (text/video)
   - Owner testimonials
   - Comparison articles
   - Market analysis

DATABASE SCHEMA UPDATES:
- Add fields for: inspectionStatus, trustScore, verificationLevel, etc.
- Create tables: PriceHistory, MarketAnalytics, InspectionReport, etc.
- Track: views, inquiries, notifications

API ENDPOINTS TO CREATE:
- All search endpoints (advanced filters)
- Comparison endpoints
- Analytics endpoints
- Review endpoints
- Wishlist endpoints
- Alert endpoints
- Messaging endpoints
- Payment endpoints (if applicable)

FRONTEND COMPONENTS:
- Enhanced search component
- Advanced filter panel
- Listing card (new version with badges)
- Listing detail (comprehensive)
- Comparison view
- Chat interface
- Review section
- Analytics charts
- Price trend charts

IMPLEMENTATION PRIORITY:
1. Advanced search & filters (HIGH)
2. Comparison feature (HIGH)
3. Reviews & ratings (HIGH)
4. Wishlist & alerts (MEDIUM)
5. Analytics & insights (MEDIUM)
6. Payment/escrow (MEDIUM)
7. Content & guides (LOW)

DESIGN SYSTEM:
- Use existing color scheme (Blue #1E3A5F, Orange #FF6B35)
- Consistent spacing & typography
- Mobile-first responsive design
- Accessibility (WCAG AA)
- Dark mode support

OUTPUT:
- All components
- All API routes
- Database schema updates
- Fully functional features
- Comprehensive comments
- Type-safe TypeScript
- Production-ready code

Start with search & filters, then comparison, then reviews. These are highest priority.
```

---

## 🎯 UNIQUE FEATURES IMPLEMENTATION PROMPTS

### **PROMPT: AI VEHICLE VALUATION & PRICING INTELLIGENCE**

```
Build AI-powered vehicle valuation and pricing intelligence system.

PROJECT: CarBikeDekho - AI Valuation Engine
TECH: Next.js, TypeScript, ML model (or API-based)

FEATURES:

1. PRICE PREDICTION ENGINE:
   
   Inputs:
   - Vehicle type, brand, model, variant
   - Year of manufacture
   - Current mileage
   - Fuel type
   - Transmission
   - Owner type
   - Condition (Excellent/Good/Fair/Poor)
   - Accident history (Yes/No/Minor)
   - Location/city
   - Season/month
   
   Outputs:
   - Fair market price range (Min, Avg, Max)
   - Seller's asking price analysis
   - "Good deal" / "Overpriced" / "Underpriced" badge
   - Depreciation rate for this vehicle
   - Expected price 1 year, 3 years, 5 years from now
   - Recommendation: "Lower price by ₹2L to sell 50% faster"

2. PRICE TREND ANALYSIS:
   - Historical price data
   - Seasonal trends (e.g., prices drop in monsoon)
   - "Best time to buy" recommendation
   - Market demand trends
   - Price volatility for model
   - Regional price differences

3. VALUATION FOR SELLERS:
   - Dynamic price recommendation
   - "Adjust price to match market" suggestion
   - Pricing competitor analysis
   - Sell time prediction based on price
   - "If you lower price by 5%, expect 3x more inquiries"

4. VALUATION FOR BUYERS:
   - "Fair price" indicator
   - Savings calculator (fair vs asking)
   - Negotiation assistance ("Try offering ₹8.5L")
   - "Best deal in your area" badge

5. MACHINE LEARNING MODEL:
   Option A: Simple regression model (can use existing data)
   - Features: mileage, year, condition, location, etc.
   - Target: actual selling price
   - Model: Linear/Polynomial regression
   
   Option B: API-based (use third-party service)
   - Call valuation API
   - Cache results
   - Update weekly

IMPLEMENTATION:
- Create /services/valuation/
- Functions: estimatePrice(), analyzePricing(), recommendations()
- Database: Store historical prices, update weekly
- API route: POST /api/valuation/estimate
- UI: Show on listing detail, search results, seller dashboard

OUTPUT:
- Complete valuation system
- Price prediction model
- Recommendation engine
- Database for historical data
- All APIs and components
```

### **PROMPT: REVIEW & REPUTATION SYSTEM**

```
Build comprehensive seller review and reputation system.

FEATURES:

1. REVIEW SYSTEM:
   - 5-star rating
   - Review categories (Communication, Condition, Price, Transaction, Honesty)
   - Written review (max 500 chars)
   - Photos with review (optional)
   - Helpful/Unhelpful voting
   - Review moderation system

2. SELLER REPUTATION SCORE:
   - Overall rating (1-5)
   - Rating distribution (% for each star)
   - Category-wise ratings (5 separate ratings)
   - Total reviews count
   - Verified buyer badge
   - Transaction success rate
   - Response rate & time
   - Listing accuracy score

3. SELLER RESPONSE TO REVIEWS:
   - Seller can add reply
   - Response time tracked
   - Flag inappropriate responses
   - Reply notification to reviewer

4. REVIEW ACTIONS:
   - Sort reviews (newest, highest rating, lowest, most helpful)
   - Filter by rating (5-star only, etc.)
   - Report inappropriate review
   - Find reviews by verified buyers only
   - Export reviews (PDF)

5. TRUST SCORE CALCULATION:
   - Weighted average of ratings
   - Response time factor
   - Transaction completion rate
   - Account age
   - Verification level
   - Result: "Trusted Seller" badge if score > threshold

DATABASE:
- Review table: id, sellerId, buyerId, listingId, rating, categories, text, timestamp
- ReviewResponse table: id, reviewId, sellerId, response, timestamp
- SellerReputation table: sellerId, averageRating, trustScore, metrics

API ENDPOINTS:
- POST /api/reviews/create (post review)
- GET /api/reviews/seller/[id] (get seller reviews)
- POST /api/reviews/[id]/helpful (mark helpful)
- POST /api/reviews/[id]/report (report inappropriate)
- GET /api/reviews/moderation (admin view)

COMPONENTS:
- ReviewCard
- ReviewForm
- ReviewsList with filtering
- SellerReputationBadge
- TrustScoreMeter (circular progress)

OUTPUT:
- Complete review system
- All components & APIs
- Moderation dashboard
- Notification system
```

### **PROMPT: MARKET ANALYTICS & INTELLIGENCE DASHBOARD**

```
Build comprehensive market analytics and intelligence system.

FEATURES:

1. PRICE TREND ANALYTICS:
   - Price history chart (1-month, 3-month, 6-month, 1-year)
   - Average price trend
   - Seasonal patterns
   - Price by segment
   - Price by brand
   - Depreciation curves (by model)

2. MARKET INSIGHTS:
   - Most searched vehicles (weekly)
   - Trending models (up/down arrow with %)
   - Regional price differences (price variance by city)
   - Fuel type trends (EV adoption %)
   - Body type popularity
   - Owner type distribution
   - Best deals this week

3. BUYER ANALYTICS:
   - Segment preferences (which segments getting more searches)
   - Price range most searched
   - Popular budget ranges
   - Geographic heat map (where most listings)
   - Seasonal trends (people looking for AC cars in summer)

4. SELLER INSIGHTS:
   - Listing success rate by price bracket
   - Average days to sell (by model, price, condition)
   - Response rate correlation with success
   - Photo count impact on sales
   - Timing to list recommendations

5. REPORTS:
   - Weekly market report
   - Monthly digest
   - Segment analysis
   - Email newsletter
   - PDF reports

VISUALIZATIONS:
- Line charts (price trends)
- Bar charts (segment comparison)
- Heat maps (geographic/temporal)
- Pie charts (distribution)
- Heatmaps (demand by segment)

DATABASE:
- DailyMarketMetrics table: date, metricType, value, segment, city
- PriceHistory table: listingId, price, date, condition
- SearchMetrics table: searchTerm, count, segment, date

API ENDPOINTS:
- GET /api/analytics/prices (price trends)
- GET /api/analytics/trends (trending vehicles)
- GET /api/analytics/market-report (full report)
- GET /api/analytics/segment-insights
- GET /api/analytics/seller-insights

PAGES:
- /app/dashboard/market-insights (public)
- /app/admin/analytics (admin dashboard)

OUTPUT:
- Complete analytics system
- All charts & visualizations
- Email reports
- Admin dashboard
- Public insights page
```

### **PROMPT: INSPECTION & CERTIFICATION PROGRAM**

```
Build certified inspection and vehicle health certification system.

FEATURES:

1. INSPECTION PROGRAM:
   - Partner with certified mechanics/inspection agencies
   - On-site inspection at seller's location or neutral location
   - Home inspection option (inspector visits)
   - Inspection report generation
   - Inspection photos (separate from listing)
   - Defect identification & costing
   - Inspection video recording (optional)
   - Inspector verification & certification

2. INSPECTION CHECKLIST:
   Categories:
   - Exterior (paint, dents, scratches, rust, lights)
   - Interior (seats, steering wheel, dashboard, AC, windows)
   - Engine (cleanliness, leaks, sounds, performance)
   - Transmission (smooth shifting, no slippage)
   - Brakes (responsiveness, condition)
   - Tires (tread depth, wear pattern, condition)
   - Lights & Signals (all working)
   - Electronics (all features working)
   - Undercarriage (no rust, leaks, corrosion)
   - Paper work (documents complete, genuine)

3. INSPECTION REPORT:
   - Detailed findings for each category
   - Severity rating (Critical, Major, Minor)
   - Cost estimation for repairs
   - Photos of issues
   - Inspector signature & date
   - "Vehicle health score" (0-100)

4. INSPECTION BOOKING:
   - Select inspection location
   - Choose date/time
   - Select inspector (if possible)
   - Track inspection status
   - Download report
   - Share report with buyer

5. TRUST SYSTEM:
   - "Inspected" badge on listing
   - Inspection partner name displayed
   - Inspector rating/verification
   - Inspection validity (3-6 months)
   - Buyer confidence increase (listings with inspection get 2x more interest)

DATABASE:
- Inspection table: id, listingId, inspectorId, date, status, score
- InspectionItem table: inspectionId, category, finding, severity, estimatedCost
- InspectionPhoto table: inspectionId, photoUrl, category
- InspectorProfile table: id, name, certification, rating, experience

API ENDPOINTS:
- POST /api/inspection/book (schedule inspection)
- GET /api/inspection/[id] (get report)
- POST /api/inspection/[id]/feedback (rate inspection)
- GET /api/inspection/partners (list partners)

FEATURES FOR SELLERS:
- Get inspection suggestion (free or paid)
- Book inspection easily
- Share inspection report with buyers
- Use inspection report in marketing

FEATURES FOR BUYERS:
- Filter "Inspected vehicles only"
- View inspection reports
- Trust badge on listings
- Compare inspection scores

OUTPUT:
- Complete inspection system
- Booking system
- Report generation
- Inspector management
- Dashboard for tracking
```

### **PROMPT: FINANCING & INSURANCE INTEGRATION**

```
Build financing options and insurance quote system.

FEATURES:

1. FINANCING CALCULATOR:
   - Loan amount selector (drag slider)
   - Tenure selector (1-7 years)
   - Interest rate (user-adjustable)
   - Down payment input
   - EMI calculation
   - Loan eligibility calculator

   Output:
   - Monthly EMI
   - Total payable amount
   - Total interest
   - Amortization schedule (month-by-month)

2. FINANCING OPTIONS:
   - Partner bank options
   - Comparison of multiple banks
   - Interest rates
   - Processing fees
   - Eligibility criteria
   - Online application link
   - Pre-approval status

3. INSURANCE INTEGRATION:
   - Insurance premium calculator
   - Coverage recommendations (third-party, comprehensive)
   - Comparison of insurance plans
   - Direct links to insurance sites
   - Insurance validity tracking

4. TOTAL COST OF OWNERSHIP:
   - Vehicle price
   - Down payment
   - EMI breakdown
   - Insurance cost (annual)
   - Maintenance cost (estimated annual)
   - Fuel cost (based on average driving)
   - Registration & transfer costs
   - Total 5-year cost

5. AFFORDABILITY ANALYSIS:
   - "Can I afford this car?" analyzer
   - Income-to-EMI ratio check
   - Debt-to-income ratio consideration
   - Budget recommendation
   - "This vehicle is X% of your monthly income" indicator

IMPLEMENTATION:
- Finance calculator component
- Insurance quote API integration
- Database: Store insurance partner details, bank details
- API: GET /api/finance/calculate-emi, /api/finance/insurance-quotes
- Pages: Finance page (within listing detail)

OUTPUT:
- Finance calculator
- Insurance integration
- Cost of ownership calculator
- Financing page
- Insurance quote page
```

### **PROMPT: COMMUNITY & SOCIAL FEATURES**

```
Build community forum, discussions, and social features.

FEATURES:

1. COMMUNITY FORUM:
   - Model-specific forums (Maruti Swift, Hyundai Creta, etc.)
   - Segment forums (SUVs, Hatchbacks, Bikes under ₹1L)
   - General discussions
   - Buy/Sell advice
   - Maintenance & repairs
   - Mileage discussions (who's getting how much mileage)
   - Threads with nested replies
   - Upvote/downvote system
   - Mark helpful answers

2. USER PROFILES:
   - User reputation in forum
   - Badges (Expert, Super User, Verified Buyer, etc.)
   - Contribution count (posts, helpful answers)
   - Follower count
   - Forum activity history

3. LIVE CHAT:
   - Seller Q&A during listing
   - Community experts available for questions
   - Real-time chat
   - Chat moderation
   - Report inappropriate users

4. CONTENT SHARING:
   - Users can share tips
   - Share photos (car modifications, maintenance)
   - Share experiences
   - Share reviews
   - Voting on content

5. SELLER Q&A:
   - Buyers ask pre-purchase questions
   - Sellers answer
   - FAQ auto-generation from Q&A
   - Rating of seller responses

DATABASE:
- ForumThread table: id, title, content, authorId, category, timestamp
- ForumReply table: id, threadId, authorId, content, upvotes, timestamp
- UserProfile table: id, reputation, badges, contributions
- SellerQA table: listingId, question, answer, helpful count

COMPONENTS:
- ForumThread
- ForumReply
- ThreadList (with search/filter)
- UserProfile
- LiveChat

OUTPUT:
- Complete forum system
- Community features
- Q&A system
- User profiles
- Reputation system
```

---

## 🚀 EXECUTION ROADMAP

**Use these prompts in this order:**

### Week 1-2: Competitor Features
1. Comprehensive Features Prompt (All-In-One)
2. Test and refine

### Week 3-4: Unique Features Phase 1
1. AI Valuation Prompt
2. Review System Prompt
3. Market Analytics Prompt

### Week 5-6: Unique Features Phase 2
1. Inspection Program Prompt
2. Financing Integration Prompt
3. Community Features Prompt

### Week 7-8: Polish & Deploy
1. Create admin dashboards
2. Test all features
3. Deploy to production

---

## 📊 FEATURE COMPARISON TABLE

| Feature | CarDekho | Cars24 | CarWale | OLX | **CarBikeDekho** |
|---------|----------|--------|---------|-----|-----------------|
| Advanced Filters | ✓ | ✓ | ✓ | ✓ | ✓ |
| Comparison | ✓ | ✓ | ✓ | ✓ | ✓ |
| Reviews | ✓ | ✓ | ✓ | ✓ | ✓ |
| Inspection Report | ✗ | ✓ | ✗ | ✗ | ✓ |
| Price Prediction | ✗ | ✗ | ✗ | ✗ | ✅ **NEW** |
| Market Analytics | ✗ | ✗ | ✓ | ✗ | ✅ **ENHANCED** |
| Community Forum | ✗ | ✗ | ✗ | ✓ | ✅ **NEW** |
| Trust Score | ✗ | ✓ | ✗ | ✓ | ✅ **ENHANCED** |
| Financing Integration | ✓ | ✓ | ✓ | ✗ | ✅ **NEW** |
| Virtual Test Drive | ✗ | ✗ | ✗ | ✗ | ✅ **NEW** |
| AI Recommendations | ✓ | ✓ | ✓ | ✗ | ✅ **ADVANCED** |

---

## ✅ YOU HAVE

✓ Complete competitor feature analysis
✓ 15+ unique features for differentiation
✓ Detailed implementation prompts for all features
✓ Execution roadmap (8 weeks)
✓ Feature prioritization
✓ Database schemas
✓ API specifications
✓ Component lists

**Total words in this document:** 15,000+
**Total prompts:** 6 detailed prompts
**Implementation time:** 8-10 weeks

---

## 🎯 NEXT STEPS

1. Start with "Comprehensive Features" prompt
2. Then "AI Valuation" prompt
3. Then "Review System" prompt
4. Continue with other unique features

Copy each prompt → Paste into Cursor AI → Execute → Move to next

**Good luck building CarBikeDekho!** 🚀
