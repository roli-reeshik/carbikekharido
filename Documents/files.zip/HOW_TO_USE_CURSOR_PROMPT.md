# How to Use the CarBikeDekho Cursor AI Prompt

## QUICK START (5 MINUTES)

### Step 1: Copy the Prompt
- Open `CarBikeDekho_Cursor_Prompt.md`
- Copy the entire content (or individual phases as needed)

### Step 2: Paste into Cursor
- Open Cursor AI Editor
- Create a new chat or conversation
- Paste the prompt content
- Cursor will start processing and generating responses

### Step 3: Follow the Phases
- Start with **PHASE 1: Feature Audit**
- Cursor will generate a checklist for you to work through
- Move sequentially through phases as you complete each

### Step 4: Use Outputs
- Cursor will generate code, specs, and implementation plans
- Save all outputs to your project
- Use generated code as starting point (modify as needed)

---

## HOW THIS PROMPT WORKS

### Two-Level Architecture

**Level 1: Audit Tasks**
- Identify current state of CarBikeDekho.com
- Find missing features
- Assess quality and functionality
- Generate missing features matrix

**Level 2: Implementation Tasks**
- Generate implementation recommendations for each feature
- Provide unique differentiation ideas
- Create code structure and database schemas
- Generate components, APIs, and test cases

### Smart Features

✅ **Adaptive**: Prompt adjusts based on your current implementation status
✅ **Specific**: Includes exact code/component names, file structures
✅ **Practical**: Every recommendation is actionable
✅ **Unique**: Emphasizes differentiation from CarDekho/CarWale
✅ **Comprehensive**: Covers frontend, backend, data, testing, deployment

---

## PHASE-BY-PHASE GUIDE

### PHASE 1: Feature Audit (Start Here!)

**What it does:**
- Lists all menus and features from CarDekho + CarWale
- Checks what's present in your current CarBikeDekho
- Identifies what's working, broken, or missing
- Rates quality of existing features

**How to use:**
```
1. Copy PHASE 1 to Cursor
2. Let Cursor generate audit output
3. Go through your CarBikeDekho.com codebase
4. Manually verify Cursor's audit results
5. Update status for each feature
6. Save the audit report
```

**Expected Output:**
A detailed matrix showing:
- Menu name
- Is it present? (YES/NO)
- Is it functional? (YES/NO/PARTIAL)
- Quality rating (1-5)
- What's missing
- Unique implementation idea

### PHASE 2: Missing Features Identification

**What it does:**
- Consolidates all missing features
- Rates them by importance & complexity
- Creates a prioritized task list
- Suggests unique implementations

**How to use:**
```
1. Copy PHASE 2 to Cursor
2. Provide results from PHASE 1
3. Cursor generates prioritized matrix
4. Use for sprint planning
5. Assign features to team members
```

**Expected Output:**
Priority matrix with:
- Feature name
- Importance level (High/Medium/Low)
- Complexity (Easy/Medium/Hard)
- Estimated effort hours
- Unique implementation idea
- Current status

### PHASE 3: Unique Differentiation Strategy

**What it does:**
- Suggests unique features not in competitors
- Bike-specific innovations
- UI/UX differentiation ideas
- Content strategy recommendations

**How to use:**
```
1. Copy PHASE 3 to Cursor
2. Review suggested unique features
3. Evaluate which align with your vision
4. Create mockups/designs for approved ones
5. Add to product roadmap
```

**Key Unique Features for Bikes:**
- Rider Height Compatibility Checker
- Real-world Mileage Database (crowdsourced)
- Riding Style Matcher
- Maintenance Cost Calculator
- Resale Value Predictor
- Modification Gallery
- Service Quality Ratings
- DIY Maintenance Guides

### PHASE 4: Implementation Roadmap

**What it does:**
- Breaks down work into 4 phases (MVP → Advanced)
- Assigns features to each phase
- Provides timeline estimates
- Lists success metrics

**How to use:**
```
1. Copy PHASE 4 to Cursor
2. Adjust timelines based on team capacity
3. Assign Phases to sprints
4. Use success metrics for acceptance criteria
5. Track progress weekly
```

**Timeline:**
- **Phase 1 (MVP): Weeks 1-4** - Basic functioning
- **Phase 2 (Core): Weeks 5-8** - Essential features
- **Phase 3 (Unique): Weeks 9-12** - Differentiation
- **Phase 4 (Advanced): Weeks 13+** - Premium features

### PHASE 5: Database & Architecture Audit

**What it does:**
- Reviews database schema
- Identifies missing tables/fields
- Recommends optimizations
- Provides API endpoint list
- Suggests code structure

**How to use:**
```
1. Copy PHASE 5 to Cursor
2. Show your current database schema
3. Cursor identifies gaps and improvements
4. Generate migration scripts
5. Create API documentation
```

**Key Tables You Need:**
- bikes (core bike data)
- reviews (expert + user reviews)
- pricing (city-wise prices)
- used_bikes (pre-owned listings)
- locators (dealers, service, charging)
- users (customer data)

### PHASE 6: Front-End Components Audit

**What it does:**
- Lists all React/Vue components needed
- Checks if they exist
- Assigns priority to missing ones
- Provides component structure

**How to use:**
```
1. Copy PHASE 6 to Cursor
2. Review component checklist
3. Identify missing components
4. Generate component stubs/templates
5. Assign to team for development
```

**Critical Components:**
- BikeDetail, BikeCard, BikeGallery
- ComparisonTable, ComparisonCards
- PriceCalculator, EMICalculator
- FilterSidebar, FilterChip
- ReviewCard, ReviewForm
- DealerMap, DealerLocator
- SellBikeWizard, UsedBikeCard

### PHASE 7: Content & Data Audit

**What it does:**
- Checks completeness of bike data
- Quality of reviews
- Coverage of content
- Identifies gaps

**How to use:**
```
1. Copy PHASE 7 to Cursor
2. Audit your current data
3. Identify missing bikes, specs, photos
4. Create content roadmap
5. Assign data entry tasks
```

**Data Quality Targets:**
- Bikes: 100+ with complete specs
- Photos: 12+ per bike (high quality)
- Reviews: 5000+ (expert + user combined)
- Dealers: 500+ mapped
- Service Centers: 1000+

### PHASE 8: Integration Checklist

**What it does:**
- Lists all third-party services needed
- Checks integration status
- Provides implementation notes
- Suggests alternatives

**How to use:**
```
1. Copy PHASE 8 to Cursor
2. Check which integrations exist
3. Identify missing integrations
4. Get implementation guides from Cursor
5. Assign integration tasks
```

**Must-Have Integrations:**
- Google Maps (dealer locator)
- Payment Gateway (Razorpay)
- Email/SMS (Twilio, SendGrid)
- CDN (CloudFront, Cloudflare)
- Analytics (Google Analytics)
- Finance Partners APIs
- Insurance Partners APIs

### PHASE 9: Testing & QA Checklist

**What it does:**
- Comprehensive test plan
- Test cases for all features
- Performance targets
- Security requirements
- Accessibility standards

**How to use:**
```
1. Copy PHASE 9 to Cursor
2. Generate test cases for your features
3. Create test matrix
4. Run automated tests
5. Perform manual testing
```

**Testing Priorities:**
1. Functional (does it work?)
2. Performance (is it fast?)
3. Security (is it safe?)
4. Mobile (works on devices?)
5. Cross-browser (works everywhere?)
6. Accessibility (is it inclusive?)

### PHASE 10: Performance & Optimization

**What it does:**
- Performance optimization strategies
- Monitoring setup
- Target metrics
- Best practices

**How to use:**
```
1. Copy PHASE 10 to Cursor
2. Review optimization recommendations
3. Implement performance improvements
4. Set up monitoring
5. Track metrics continuously
```

**Target Metrics:**
- Page Load: <2 seconds
- First Input Delay: <100ms
- Largest Contentful Paint: <2.5s
- Lighthouse Score: >90 (all categories)

---

## WORKFLOW SCENARIOS

### Scenario 1: Starting From Scratch

1. Use **PHASE 1** to plan from zero
2. Use **PHASE 4** to create 4-week roadmap
3. Use **PHASE 3** to identify unique features
4. Use **PHASE 5 & 6** to design architecture
5. Start development with clear structure

### Scenario 2: Improving Existing Site

1. Use **PHASE 1** to audit current state
2. Use **PHASE 2** to identify missing features
3. Use **PHASE 4** to prioritize additions
4. Use **PHASE 7** to improve content
5. Use **PHASE 9** to increase quality

### Scenario 3: Adding Specific Feature

1. Find feature in **PHASE 2** matrix
2. Jump to relevant phase (usually **PHASE 6** for components)
3. Get Cursor to generate that feature's specs
4. Get Cursor to generate component code
5. Get Cursor to generate test cases

### Scenario 4: Performance Optimization Sprint

1. Use **PHASE 10** for optimization strategies
2. Use **PHASE 9** for performance testing
3. Use database optimization from **PHASE 5**
4. Monitor with tools from **PHASE 8**
5. Measure improvements against targets

---

## TIPS FOR BEST RESULTS

### ✅ DO:
- Read each phase completely before starting
- Be specific about current state when asking Cursor
- Share code/database schema with Cursor (copy/paste)
- Ask Cursor for detailed specs before coding
- Use generated code as starting point (customize it)
- Ask for help with specific problems (Cursor is great at this)
- Iterate - ask Cursor to improve/refine suggestions
- Break complex features into smaller tasks
- Share requirements clearly
- Test generated code before production

### ❌ DON'T:
- Copy/paste code directly without understanding it
- Skip Phase 1 (audit) - understanding current state is crucial
- Ignore performance optimization (do it as you go)
- Forget to test generated features
- Use outdated libraries/frameworks
- Skip database design phase
- Assume all third-party APIs will work perfectly
- Launch without security audit
- Ignore mobile experience
- Defer technical debt (address as you find it)

---

## PROMPTS TO USE WITH CURSOR

### After copying a phase, follow up with these prompts:

**For Audit:**
```
"Based on what you've outlined in PHASE 1, please check my current CarBikeDekho codebase 
at [provide path] and generate an audit report with actual status of each feature"
```

**For Implementation:**
```
"For the [Feature Name] that's missing, provide:
1. React component code
2. Database schema changes
3. API endpoint specifications
4. Test cases
Make it unique to bikes, not a copy of CarDekho/CarWale"
```

**For Debugging:**
```
"I'm having an issue with [describe problem]. 
Here's my code: [paste code]
Can you identify the issue and provide fix?"
```

**For Performance:**
```
"Help me optimize [component/page]. 
Current load time: [X] seconds. 
Target: 2 seconds. 
Here's the code: [paste]"
```

**For Design Uniqueness:**
```
"This feature is too similar to CarDekho. 
How can I redesign it to be unique for bike enthusiasts?
Here's current design: [describe/paste]"
```

---

## CHECKLIST FOR USING THE PROMPT

### Before Development Sprint:
- [ ] Copy relevant phase to Cursor
- [ ] Run audit/identify gaps
- [ ] Review Cursor's recommendations
- [ ] Create tickets/tasks from matrix
- [ ] Assign to team members
- [ ] Estimate effort
- [ ] Set success criteria

### During Development:
- [ ] Reference implementation specs from Cursor
- [ ] Ask Cursor for specific component code
- [ ] Use generated test cases
- [ ] Implement performance optimizations
- [ ] Regular code reviews
- [ ] Track progress against roadmap

### Before Launch:
- [ ] Complete Phase 9 (Testing)
- [ ] Complete Phase 10 (Performance)
- [ ] Security audit (Phase 8)
- [ ] All test cases passing
- [ ] Performance metrics met
- [ ] SEO checklist done
- [ ] Accessibility tested

### After Launch:
- [ ] Monitor with Phase 8 tools
- [ ] Track Phase 10 metrics
- [ ] Collect user feedback
- [ ] Plan Phase 2 features
- [ ] Iterate based on data

---

## SUMMARY: YOUR ROADMAP

```
Week 1-2: AUDIT (Phase 1-2)
→ Use Cursor to understand current state
→ Create comprehensive feature matrix
→ Prioritize what needs doing

Week 3-4: PLAN (Phase 3-4)
→ Design unique approach for each missing feature
→ Create 4-week implementation roadmap
→ Plan architecture (Phase 5-6)

Week 5-8: BUILD (Phase 6)
→ Generate components with Cursor
→ Implement core features
→ Write unit tests (Phase 9)

Week 9-12: ENHANCE (Phase 3)
→ Add unique bike-specific features
→ Improve UI/UX
→ Optimize performance (Phase 10)

Week 13+: SCALE
→ Advanced features (Phase 4)
→ Mobile app
→ Marketplace expansion
→ Community features
```

---

## FINAL TIPS

1. **Customize for Your Team**: Adjust timelines based on team size and skill level
2. **Iterate Fast**: Use Cursor to generate, test, get feedback, iterate
3. **Stay Unique**: Always ask Cursor "how can we make this unique for bikes?"
4. **Quality Over Speed**: Better to launch fewer features well than many features poorly
5. **User-Focused**: Always ask "what does the bike buyer/seller need?"
6. **Data-Driven**: Use Phase 9 to get data on what's working
7. **Stay Organized**: Keep audit results and roadmaps updated
8. **Communicate**: Share Cursor outputs with team regularly

---

## NEED HELP?

If you get stuck:
1. Go back to relevant phase
2. Provide more specific context to Cursor
3. Share actual code/database schema
4. Ask Cursor for step-by-step guidance
5. Break complex problems into smaller ones

Remember: Cursor is your assistant. Feed it detailed information for better outputs.

Good luck building CarBikeDekho.com! 🚲🏍️

---

**Last Updated:** July 31, 2026
**Version:** 1.0
**Status:** Ready for Use

