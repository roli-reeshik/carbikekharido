# CarBikeDekho.com - Comprehensive Feature Audit & Implementation Prompt for Cursor

## CONTEXT & OVERVIEW
You are working on **CarBikeDekho.com**, an innovative Indian two-wheeler marketplace that combines the best features from CarDekho.com and CarWale.com, but with unique differentiation for bikes/motorcycles/scooters. This prompt guides you through a systematic audit and implementation process.

---

## PHASE 1: FEATURE AUDIT CHECKLIST

### A. NAVIGATION & MENU STRUCTURE AUDIT

**Instruction for Cursor:**
```
AUDIT TASK: Review the current navigation/menu structure of CarBikeDekho.com

Compare against these expected menus:
1. NEW BIKES (with sub-categories)
   - Explore by Type (Motorcycle, Scooter, Moped, Electric Bike)
   - Electric Two-Wheelers
   - Popular Bikes
   - Upcoming Launches
   - By Brand
   - Compare Bikes
   - Offers & Discounts
   - Dealer/Service Center Locator
   - EV Charging Locator (for e-bikes)

2. USED BIKES (with sub-categories)
   - Browse Used Bikes
   - Sell Your Bike
   - Bike Valuation
   - City-wise Listings

3. REVIEWS & NEWS (with sub-categories)
   - News & Updates
   - Expert Reviews
   - User Reviews
   - Video Content
   - Buying Guides

4. TOOLS & CALCULATORS
   - On-Road Price Calculator
   - Bike Loan Calculator
   - Insurance Calculator
   - Mileage Calculator

5. RESOURCES
   - Maintenance Tips
   - Riding Guides
   - Accessories Guide

For each menu:
- Is it present? (YES/NO)
- Is it functional? (YES/NO/PARTIAL)
- Quality assessment (1-5 stars)
- What's missing?
- Provide implementation recommendation with unique twist

Output as: | Menu Item | Present | Functional | Quality | Missing | Unique Implementation Idea |
```

### B. CORE FEATURES AUDIT

**Instruction for Cursor:**
```
AUDIT TASK: Check if these core features exist and are functional

PRICE & VALUATION FEATURES:
1. On-Road Price Calculator (multi-city)
   Status: __ / Implementation: __
2. Ex-Showroom Price Display
   Status: __ / Implementation: __
3. Used Bike Valuation Tool
   Status: __ / Implementation: __
4. Price Comparison Tool
   Status: __ / Implementation: __
5. Price Trend History
   Status: __ / Implementation: __

SEARCH & FILTER FEATURES:
1. Advanced Search Filters (Budget, Brand, Type, Fuel, Features)
   Status: __ / Implementation: __
2. Multi-criteria Search
   Status: __ / Implementation: __
3. Filter by Bike Type (Cruiser, Naked, Sports, Adventure, Touring, Commuter, Scooter, Electric)
   Status: __ / Implementation: __
4. Filter by Engine Size (CC)
   Status: __ / Implementation: __
5. Filter by Mileage/Average
   Status: __ / Implementation: __
6. Filter by Transmission Type
   Status: __ / Implementation: __

COMPARISON & ANALYSIS FEATURES:
1. Bike Comparison Tool (2-3 bikes side-by-side)
   Status: __ / Implementation: __
2. Spec Comparison
   Status: __ / Implementation: __
3. Performance Comparison (Power, Torque, Acceleration)
   Status: __ / Implementation: __
4. Feature Comparison
   Status: __ / Implementation: __
5. Visual Side-by-Side Comparison
   Status: __ / Implementation: __

CONTENT & INFORMATION FEATURES:
1. Expert Reviews (Professional Reviews)
   Status: __ / Implementation: __
2. User Reviews (Customer Feedback - minimum 5,000+)
   Status: __ / Implementation: __
3. Latest News Feed
   Status: __ / Implementation: __
4. Video Reviews/Walkarounds
   Status: __ / Implementation: __
5. Detailed Specifications Database
   Status: __ / Implementation: __
6. 360° Bike View/Visual Experience
   Status: __ / Implementation: __
7. High-Quality Photo Gallery
   Status: __ / Implementation: __
8. Technical Specifications
   Status: __ / Implementation: __

CALCULATOR FEATURES:
1. EMI/Bike Loan Calculator
   Status: __ / Implementation: __
2. Insurance Premium Calculator
   Status: __ / Implementation: __
3. Mileage Calculator (expected vs actual)
   Status: __ / Implementation: __
4. Maintenance Cost Calculator
   Status: __ / Implementation: __
5. Running Cost Calculator
   Status: __ / Implementation: __

BUYING & SELLING FEATURES:
1. Sell Your Used Bike (Simple 3-5 step process)
   Status: __ / Implementation: __
2. Bike Valuation Tool (Instant)
   Status: __ / Implementation: __
3. Certified Used Bikes Section
   Status: __ / Implementation: __
4. Connect with Dealers
   Status: __ / Implementation: __
5. Test Drive Booking
   Status: __ / Implementation: __
6. Instant Notifications/Alerts
   Status: __ / Implementation: __

LOCATOR & DIRECTORY FEATURES:
1. Bike Dealer/Showroom Locator
   Status: __ / Implementation: __
2. Service Center Locator
   Status: __ / Implementation: __
3. Spare Parts Shop Locator
   Status: __ / Implementation: __
4. EV Charging Station Locator (for e-bikes)
   Status: __ / Implementation: __
5. Petrol Station Locator
   Status: __ / Implementation: __
6. Fuel Price Tracker
   Status: __ / Implementation: __

COMMUNITY & ENGAGEMENT FEATURES:
1. User Review System (Rating & Comments)
   Status: __ / Implementation: __
2. User Photo Uploads (Real customer photos of bikes)
   Status: __ / Implementation: __
3. Wishlist/Save Favorites
   Status: __ / Implementation: __
4. Price Alert System
   Status: __ / Implementation: __
5. New Launch Alerts
   Status: __ / Implementation: __
6. Bike Forum/Community (Optional)
   Status: __ / Implementation: __

SPECIAL SECTIONS:
1. Electric Bikes Section (Dedicated)
   Status: __ / Implementation: __
2. Upcoming Bike Launches
   Status: __ / Implementation: __
3. New Bike Launches (Latest)
   Status: __ / Implementation: __
4. Bike Comparison Lists (Pre-made popular matchups)
   Status: __ / Implementation: __
5. Bike Collections (By category, budget, etc.)
   Status: __ / Implementation: __
6. Accessories Marketplace
   Status: __ / Implementation: __

For each feature:
- Current Status (Working/Broken/Missing/Partial)
- Quality Rating (1-5)
- What needs fixing/adding
- Recommended unique implementation approach
```

### C. VISUAL & UX FEATURES AUDIT

**Instruction for Cursor:**
```
AUDIT TASK: Evaluate visual and user experience features

BIKE VIEWING FEATURES:
1. 360° Bike Visualization
   - Current Implementation: __
   - Works smoothly: YES/NO
   - Unique Approach Needed: __
   - Recommendation: Use WebGL or Three.js with bike-specific camera angles (side, top, rear, detail shots of design elements)

2. Photo Gallery
   - Number of photos per bike: __
   - Photo quality (resolution): __
   - Photo categories (exterior, interior, details, action): YES/NO
   - Zoom functionality: YES/NO
   - Video support: YES/NO
   - Recommendation: Implement AI-powered smart cropping and highlight key design features specific to each bike

3. Video Integration
   - Expert walkaround videos: YES/NO
   - User-uploaded videos: YES/NO
   - Test ride videos: YES/NO
   - Specification explanation videos: YES/NO
   - Recommendation: Create interactive video guides with clickable spec overlays

4. Comparison Visuals
   - Side-by-side layout: YES/NO
   - Highlighting differences: YES/NO
   - Visual infographics: YES/NO
   - Recommendation: Use animated comparisons showing actual size differences (wheel size, seat height, etc.)

MOBILE EXPERIENCE:
1. Mobile Responsiveness: YES/NO / Quality: __/5
2. Mobile App (iOS/Android): YES/NO
3. App-exclusive features: __
4. Mobile-specific optimizations: YES/NO
5. Progressive Web App (PWA): YES/NO
6. Recommendation: Implement app-like experience with offline browsing capability

LAYOUT & DESIGN UNIQUENESS:
1. Does it look like CarDekho copy?: YES/NO
2. Does it look like CarWale copy?: YES/NO
3. Unique design elements: __ (list them)
4. Branding consistency: YES/NO
5. User flow intuitiveness: __/5
6. Recommendation: Design with bike enthusiast aesthetics - implement design elements that appeal to riders (not car buyers)
```

---

## PHASE 2: MISSING FEATURES IDENTIFICATION

### Create a Missing Features Matrix

**Instruction for Cursor:**
```
TASK: Create a comprehensive matrix of MISSING features

Format:
| Feature Name | Importance (High/Medium/Low) | Complexity (Easy/Medium/Hard) | Estimated Effort | Priority | Unique Implementation Idea | Status |
|---|---|---|---|---|---|---|

HIGH PRIORITY FEATURES (Must Have):
1. On-Road Price Calculator (Multi-city, accurate)
2. Used Bike Valuation Tool
3. Bike Comparison Tool
4. Advanced Search & Filters
5. Expert Review System
6. User Review System (5,000+)
7. EMI Calculator
8. Insurance Calculator
9. Dealer/Service Center Locator
10. Used Bike Marketplace

MEDIUM PRIORITY FEATURES (Should Have):
1. 360° Bike Viewer
2. Video Review System
3. Accessories Marketplace
4. Maintenance Cost Calculator
5. Mileage Calculator
6. Bike Photo Gallery
7. News/Updates Feed
8. Bike Collections
9. Price Trend History
10. Spare Parts Locator

LOW PRIORITY FEATURES (Nice to Have):
1. Bike Forum/Community
2. Social Sharing
3. AR Try-on (Bike in different colors)
4. Route Planning (Bike-specific routes)
5. Riding Tips Database
6. Bike Care Guide
7. Modification Ideas
8. Bike Ownership Calculator
9. Resale Value Predictor
10. Bike Insurance Comparison

For EACH missing feature, generate:
- Implementation approach
- Code structure/components needed
- Database schema requirements
- API integrations needed
- Testing strategy
- Unique twist to differentiate from competitors
```

---

## PHASE 3: UNIQUE DIFFERENTIATION STRATEGY

### Instruction for Cursor:

```
TASK: Design UNIQUE features that CarDekho/CarWale don't have (but adapted for bikes)

For a Two-Wheeler specific marketplace, implement UNIQUE features:

1. BIKE-SPECIFIC FEATURES (Not in car sites):
   
   A. Specification Features Unique to Bikes:
      - Engine Displacement (CC) Filter & Compare
      - Handlebar Type Comparison (Sport, Cruiser, Adventure)
      - Seat Height & Comfort Comparison (Important for riders)
      - Kerb Weight Comparison (Performance impact)
      - Fuel Tank Capacity (Range calculator)
      - Top Speed & 0-100 Performance
      - Emission Standards (BS6, etc.)
      - Warranty Period & Coverage
      - Service Interval Tracker
      
      Implementation Idea:
      Create "Rider Profile" matching - users input their height, weight, riding style, 
      and get AI-recommended bikes based on physical fit and handling characteristics

   B. Rider-Centric Features:
      - Rider Height/Build Compatibility Checker
        Implementation: Let users input height/inseam and see which bikes fit them physically
      
      - Riding Style Matcher
        Implementation: Quiz-based system (Commute, Sport, Adventure, Cruiser, Urban)
        Returns best bike matches with reasoning
      
      - Real-World Mileage Comparison
        Implementation: Crowdsourced actual mileage data from owners
        Show average, best, worst case scenarios
      
      - Road Conditions Database
        Implementation: Which bikes perform best on different road types
        (highways, city, offroad, mountain passes)
      
      - Fuel Economy Comparison Tool
        Implementation: Compare true running cost per km across different bikes
        Include toll, maintenance, insurance in calculations

   C. Community & User-Generated Content:
      - Owner Photo Gallery
        Implementation: Real riders uploading photos of their bikes
        with bike ID/model tags for authenticity
      
      - Riding Routes & Reviews
        Implementation: Users share favorite riding routes with bike suitability ratings
      
      - Modification Gallery
        Implementation: Users share bike modifications, accessories installed
      
      - Owner Stories
        Implementation: Personal narratives of bike ownership experience
      
      - Real-World Reliability Reports
        Implementation: Aggregate data on common issues, maintenance costs, resale value

   D. Maintenance & Care Features:
      - Service Center Ratings & Reviews
        Implementation: Dedicated section for service quality reviews
      
      - Spare Parts Availability Tracker
        Implementation: Check availability of parts in different cities
      
      - DIY Maintenance Guide Library
        Implementation: Video tutorials for common maintenance tasks
      
      - Maintenance Cost Calculator
        Implementation: Estimate total cost of ownership for first 3/5/10 years
      
      - Warranty Comparison Tool
        Implementation: Compare warranty terms across bike brands

   E. Bike Rental & Test Drive Integration:
      - Test Drive Locator
        Implementation: Find nearby showrooms offering test drives
      
      - Rental Partnership Integration
        Implementation: Try before you buy - rent the bike for a day
      
      - Delivery Trial Service
        Implementation: Bike delivered to your location for trial

   F. Buying Decision Tools:
      - EMI Calculator (Bike-specific)
        Implementation: Include GST, registration, insurance
      
      - Total Cost of Ownership Calculator (5-year projection)
        Implementation: Include maintenance, fuel, insurance, battery replacement (for e-bikes)
      
      - Resale Value Predictor
        Implementation: Estimate bike value after 3/5/10 years based on historical data
      
      - Insurance Premium Comparison
        Implementation: Compare quotes from multiple insurers

   G. Electric Bike Features:
      - Battery Range Calculator
        Implementation: Calculate real-world range based on riding conditions
      
      - Charging Station Finder
        Implementation: Map-based locator for charging points
      
      - Charging Time Calculator
        Implementation: How long to charge, cost per charge
      
      - Battery Health Tracker (for used e-bikes)
        Implementation: Estimate battery degradation for used models

   H. Accessories & Customization:
      - Accessories Recommendation Engine
        Implementation: AI recommends accessories based on bike type and owner preferences
      
      - Helmet Compatibility Checker
        Implementation: Recommend helmets that look good with specific bikes
      
      - Bike Customization Builder
        Implementation: Virtual tool to visualize bikes with different colors/customizations
      
      - Parts Compatibility Checker
        Implementation: Verify if parts/upgrades fit specific bike models

2. DESIGN DIFFERENTIATION (Visual/UX Unique):

   A. Rider-Centric Interface:
      - Implement dark theme by default (appeals to riders, reduces eye strain)
      - Use motorcycle/adventure photography aesthetic
      - Include riding action shots, not just static bike photos
      - Design cards with "Rider Ready" badges
      
   B. Interactive Elements:
      - Animated spec comparisons (showing relative differences visually)
      - Interactive bike visualizer (rotate, zoom on specific parts)
      - Swipe-based comparison interface (mobile)
      - Hover-based feature highlights
      
   C. Data Visualization:
      - Power/Torque curves (visual graph comparison)
      - Acceleration graphs (0-100 time comparison)
      - Efficiency ratings (visual bars, not just numbers)
      - Comfort index (visualized, not just text)

3. PERFORMANCE & SEO DIFFERENTIATION:
   - Fast loading (critical for mobile users)
   - SEO optimized for long-tail keywords (e.g., "best 150cc bike for heavy riders")
   - Structured data markup for bikes
   - Rich snippets showing price, specifications
   - Schema.org implementation for vehicles

4. CONTENT DIFFERENTIATION:
   - Rider interviews (Owner stories)
   - Riding condition guides (monsoon bikes, highway bikes, offroad bikes)
   - Lifestyle content (not just specs)
   - Monthly trend reports (What bikes are riders choosing)
   - Regional bike preferences analysis

5. PARTNERSHIP DIFFERENTIATION:
   - Direct integration with: Bike loan providers, Insurance companies, 
     Helmet manufacturers, Accessories brands
   - Exclusive test drive packages
   - Bike maintenance partnerships
```

---

## PHASE 4: IMPLEMENTATION ROADMAP

### Instruction for Cursor:

```
TASK: Create detailed implementation plan

CREATE A PHASED IMPLEMENTATION ROADMAP:

PHASE 1: MVP (Minimum Viable Product) - Weeks 1-4
Priority: Must-Have Features Only
Features:
- Browse new bikes (with brand/type filters)
- View bike details (specs, price, photos)
- Used bikes section (basic browse)
- Basic bike comparison (2 bikes)
- On-road price checker
- Review display (manual initially)
- Dealer locator (map-based)
- Mobile responsive design

Success Metrics:
- 100% functionality
- <3s load time
- 100% mobile responsive
- No critical bugs

PHASE 2: CORE FEATURES - Weeks 5-8
Features:
- Advanced search & filters
- EMI calculator
- Insurance calculator
- 360° bike viewer
- Expert review system setup
- User review system (with moderation)
- Bike comparison (3+ bikes)
- Sell your bike feature
- Service center locator
- Price comparison tool

Success Metrics:
- All features working
- 5000+ user reviews
- Dealer satisfaction
- 95% uptime

PHASE 3: UNIQUE FEATURES - Weeks 9-12
Features:
- Rider profile matcher
- Real-world mileage database
- Riding style recommender
- Maintenance cost calculator
- Resale value predictor
- Accessories marketplace
- Owner photo gallery
- Modification showcase
- DIY maintenance guides
- Riding routes database

Success Metrics:
- High user engagement
- Regular user-generated content
- Community growth
- Reduced dealer support tickets

PHASE 4: ADVANCED FEATURES - Weeks 13+
Features:
- AR bike visualizer
- Video review system
- Live chat support
- Personalized recommendations
- Bike ownership cost tracker
- Advanced analytics dashboard
- Social features
- Mobile app launch
- API for partners

Success Metrics:
- App store ratings >4.5
- Daily active users growth
- Partner satisfaction
- Revenue generation capability

For EACH phase:
1. List features to implement
2. Database schema changes needed
3. API endpoints to create
4. Frontend components to build
5. Testing requirements
6. Deployment steps
7. Performance benchmarks
8. Rollback procedures
```

---

## PHASE 5: DATABASE & ARCHITECTURE AUDIT

### Instruction for Cursor:

```
TASK: Review database and architecture for feature support

AUDIT CURRENT DATABASE:

1. Bikes Table Schema - Should include:
   - Basic Info: id, brand, model, year, type, segment
   - Specifications: cc, power, torque, mileage, top_speed, weight
   - Physical: seat_height, fuel_tank, wheelbase, ground_clearance
   - Features: ABS, traction_control, led_headlight, smartphone_connectivity
   - Pricing: ex_showroom_price, on_road_price (by city), warranty_period
   - Media: thumbnail_image, gallery_images[], video_url, 360_viewer_link
   - Status: active, launch_date, discontinued_date
   - Metadata: created_at, updated_at, ratings_aggregate

2. Reviews Table - Should support:
   - Expert reviews (author, publication, rating, full_text, date)
   - User reviews (reviewer_id, rating, title, text, photos[], helpful_count, date)
   - Review moderation (flagged, approved, auto_verified)

3. Pricing Table - Should track:
   - City-wise pricing (bike_id, city_id, ex_showroom, on_road, date)
   - Price history (for trend analysis)
   - Variant pricing (each variant has separate pricing)

4. Used Bikes Table - Should include:
   - Basic: id, bike_id, listing_id, owner_id, condition
   - Physical: registration_year, mileage, color, accident_history
   - Valuation: estimated_value, listed_price, sold_price
   - Media: photos[], documents[], inspection_report_pdf
   - Status: active, sold, pending_verification, flagged

5. Locator Tables - Should include:
   - Dealerships: id, brand_id, location, lat/lng, contact, reviews
   - Service Centers: id, bike_brand, location, lat/lng, contact, rating
   - EV Charging: id, location, lat/lng, charger_type, provider, availability
   - Petrol Stations: id, location, lat/lng, fuel_price_history

6. User Tables - Should include:
   - Users: id, profile, preferences, saved_bikes[], wishlist
   - User Reviews: id, bike_id, user_id, rating, text, verified_purchase
   - Alerts: user_id, alert_type (price, launch, new_review), bike_id, active

RECOMMENDED SCHEMA UPDATES:
- Add rider_profile table (height, weight, riding_style, budget, preferences)
- Add bike_compatibility table (which bikes suit which rider profiles)
- Add maintenance_costs table (brand, model, service type, estimated_cost)
- Add real_mileage table (crowdsourced actual mileage data)
- Add modification_gallery table (user modifications with bike_id, photos, parts_used)

PERFORMANCE OPTIMIZATION:
- Index frequently searched columns (brand, type, price_range, city)
- Cache on-road price calculations
- CDN for images and 360° viewer assets
- Database read replicas for high-traffic queries

API REQUIREMENTS:
- GET /bikes (with filters, pagination)
- GET /bikes/:id (detailed view)
- GET /bikes/:id/comparison
- GET /bikes/valuation (for used bikes)
- GET /dealers/nearby (with lat/lng)
- GET /prices/:bike_id/by-city
- POST /reviews (user reviews)
- GET /reviews/:bike_id
- POST /alerts (user price alerts)
- And more...

CODE STRUCTURE RECOMMENDATIONS:
- Controllers: BikeController, PriceController, ReviewController, DealerController
- Services: BikeService, ValuationService, ComparisonService, LocationService
- Repositories: BikeRepository, ReviewRepository, PriceRepository
- Models: Bike, Review, Dealer, ServiceCenter, UsedBike
- Utils: PriceCalculator, CompatibilityMatcher, ImageOptimizer
- Middleware: CacheMiddleware, AuthMiddleware, ErrorHandler
```

---

## PHASE 6: FRONT-END COMPONENTS AUDIT

### Instruction for Cursor:

```
TASK: Review all frontend components for completeness

ESSENTIAL COMPONENTS CHECKLIST:

NAVIGATION & LAYOUT:
- [ ] Header/Navigation Bar (with search, login, menu)
- [ ] Footer with links and info
- [ ] Breadcrumbs (for navigation context)
- [ ] Search Bar (with autocomplete suggestions)
- [ ] Mobile Menu/Hamburger
- [ ] Filter Sidebar (desktop & mobile versions)

HOME PAGE COMPONENTS:
- [ ] Hero Banner (rotating featured bikes)
- [ ] Search Section (prominent placement)
- [ ] Featured Bikes Section
- [ ] New Launches Section
- [ ] Comparison Showcase
- [ ] Testimonials/User Reviews Carousel
- [ ] Call-to-action Buttons
- [ ] Footer

BIKE LISTING PAGE:
- [ ] Filter Panel (budget, brand, type, cc, mileage)
- [ ] Bike Cards (image, name, price, rating, quick details)
- [ ] Sorting Options (price, popularity, newest, rating)
- [ ] Pagination
- [ ] Grid/List View Toggle
- [ ] Price Range Slider
- [ ] Multi-select Filters
- [ ] Applied Filters Display with clear option

BIKE DETAIL PAGE:
- [ ] High-quality image gallery (min 12 photos)
- [ ] Image zoom functionality
- [ ] 360° viewer (if available)
- [ ] Price Section (ex-showroom, on-road by city)
- [ ] Specification Section (organized by category)
- [ ] Feature Highlights (key points)
- [ ] Video Player (walkaround/review)
- [ ] Comparison CTA (compare with other bikes)
- [ ] Reviews Section (expert + user reviews)
- [ ] Dealer Locator (find and contact dealers)
- [ ] Test Drive Button
- [ ] Wishlist/Save Button
- [ ] Share Buttons (social, email, WhatsApp)
- [ ] Related/Recommended Bikes
- [ ] FAQ Section

COMPARISON PAGE:
- [ ] Bike Selection (add up to 3 bikes)
- [ ] Spec Comparison Table (all specs)
- [ ] Visual Comparison (side-by-side images)
- [ ] Feature Highlights Comparison
- [ ] Price Comparison
- [ ] Rating Comparison
- [ ] Pros/Cons Summary for each bike
- [ ] Individual Detail Links
- [ ] Comparison Export (PDF/Email)
- [ ] Remove Bike from Comparison

CALCULATOR PAGES:
A. Price Calculator:
   - [ ] On-road price breakdown
   - [ ] Tax calculation
   - [ ] Insurance amount
   - [ ] Registration fees
   - [ ] City selector
   - [ ] Display for multiple cities comparison

B. EMI Calculator:
   - [ ] Principal amount input
   - [ ] Interest rate slider
   - [ ] Tenure selection
   - [ ] Monthly EMI display
   - [ ] Total amount payable
   - [ ] Visual chart (amortization)
   - [ ] Bank partner links

C. Insurance Calculator:
   - [ ] Bike selection
   - [ ] Coverage type selection
   - [ ] Age input (for premium calculation)
   - [ ] Claims history
   - [ ] Insurer selection
   - [ ] Premium quotes comparison
   - [ ] Direct buy option

USED BIKES SECTION:
- [ ] Browse used bikes (by city)
- [ ] Advanced filters (price, year, mileage, condition)
- [ ] Used bike cards (price, year, mileage, location, seller rating)
- [ ] Valuation Tool (sell bike section)
- [ ] List Your Bike Form (5-step wizard)
- [ ] Bike Details Upload
- [ ] Photo Upload
- [ ] Contact Seller CTA
- [ ] Certified Used Badge
- [ ] Seller Rating Display

REVIEW SECTION:
- [ ] Expert Review Display (formatted article)
- [ ] User Review Carousel
- [ ] Review Rating Breakdown (star distribution)
- [ ] Filter Reviews (by rating, verified purchases)
- [ ] Sort Reviews (most helpful, most recent)
- [ ] User Review Form (rating, title, text, photos)
- [ ] Helpful/Unhelpful Votes
- [ ] Verified Purchase Badge
- [ ] Review Moderation Indicators

DEALER LOCATOR:
- [ ] Map Integration (Google Maps)
- [ ] Dealer Listings (with address, phone, hours)
- [ ] Dealer Reviews/Ratings
- [ ] Filter by Brand
- [ ] Filter by Service Type
- [ ] Contact Options (call, email, direction)
- [ ] Working Hours Display
- [ ] Test Drive Booking

TOOLS & FEATURES:
- [ ] Wishlist Display (user dashboard)
- [ ] Price Alerts Management (active alerts, edit, delete)
- [ ] Bike Comparison History
- [ ] Search History
- [ ] Recently Viewed Bikes
- [ ] Personal Profile (for saved preferences)
- [ ] Settings Page (alerts, preferences, privacy)

MOBILE-SPECIFIC COMPONENTS:
- [ ] Bottom Navigation Bar (important features quick access)
- [ ] Swipe-based Comparisons
- [ ] One-tap Call/Message Dealer
- [ ] Mobile Photo Gallery (swipe)
- [ ] Expandable Specs (tap to see more)
- [ ] Fixed CTA buttons (visible while scrolling)
- [ ] Mobile Form Optimization (easy inputs)

MISSING COMPONENTS TO CREATE:
(Cursor will identify and list these)
- Component name
- Purpose
- Design approach
- Interactions required
- Data dependencies
- Estimated build time

COMPONENT CODE STRUCTURE SHOULD FOLLOW:
/components
  /layout (Header, Footer, Navigation)
  /common (Button, Card, Modal, Spinner)
  /bikes (BikeCard, BikeDetail, BikeGallery)
  /comparison (ComparisonTable, ComparisonCards)
  /filters (FilterSidebar, FilterChip, RangeSlider)
  /reviews (ReviewCard, ReviewForm, RatingBreakdown)
  /calculators (PriceCalc, EMICalc, InsuranceCalc)
  /locators (DealerMap, DealerCard, LocationFilter)
```

---

## PHASE 7: CONTENT & DATA AUDIT

### Instruction for Cursor:

```
TASK: Audit content completeness and quality

CONTENT AUDIT CHECKLIST:

BIKE DATABASE CONTENT:
Current Status:
- Total bikes in database: __
- Brands covered: __ / 50+ target
- Specifications completeness: __%
- Photos per bike (average): __ (target: 12+)
- Video content per bike: __ (target: 1+ walkaround)

Content Quality Issues:
- Incomplete specifications: List __
- Missing prices for cities: List __
- Poor quality images: List __
- Missing brand information: List __

REVIEWS DATABASE:
Current Status:
- Expert reviews count: __ (target: 1000+)
- User reviews count: __ (target: 5000+)
- Average review length: __ words (target: 150+)
- Review coverage (% of bikes reviewed): __%
- Expert publication coverage: __ (target: 20+)

CONTENT GAPS:
- Bikes with no reviews: List top 20
- Brands with poor coverage: List
- Unverified reviews: Count and plan moderation

NEWS & UPDATES:
Current Status:
- News articles (last 30 days): __
- News sources/brands covered: __
- Update frequency: __ (target: daily)

PRODUCT DESCRIPTIONS:
Quality Assessment:
- Unique descriptions (not copy-pasted): __%
- Keyword optimized: YES/NO
- Highlight key differentiators: YES/NO
- Include buyer psychology elements: YES/NO
- SEO-friendly: YES/NO

LOCATOR DATA:
Current Status:
- Dealerships mapped: __ (target: 500+)
- Service centers mapped: __ (target: 1000+)
- EV charging stations (e-bikes): __ 
- Petrol stations: __
- Data freshness: __ (target: updated monthly)
- Geo-accuracy: _% (target: 99%+)

DATA ENRICHMENT TASKS:
1. Add missing specifications for all bikes
2. Source high-quality images (minimum 1080px resolution)
3. Recruit expert reviewers (biking publications, YouTubers)
4. Implement user review incentive program
5. Collect dealer/service center information
6. Add video content (walkarounds, reviews)
7. Write SEO-optimized meta descriptions
8. Create unique product descriptions
9. Add comparison guides
10. Create buying guides by segment

UNIQUE CONTENT IDEAS:
1. "Rider Stories" - Real owner experiences with bikes
2. "Monthly Trend Report" - What bikes riders are searching for
3. "Regional Preferences" - Popular bikes by state/region
4. "Maintenance Diaries" - Cost to maintain different bikes
5. "Resale Value Analysis" - How bike values depreciate
6. "Reliability Reports" - Crowdsourced problem data
7. "Riding Condition Guides" - Best bikes for different weather/terrain
8. "Customization Ideas" - Gallery of modified bikes

CONTENT AUTOMATION:
- Auto-generate spec comparisons (requires template)
- Auto-calculate maintenance costs (requires data)
- Auto-generate price comparisons (requires API)
- Auto-match user profiles to bikes (requires algorithm)
```

---

## PHASE 8: INTEGRATION CHECKLIST

### Instruction for Cursor:

```
TASK: Identify all third-party integrations needed

REQUIRED INTEGRATIONS:

1. PAYMENT GATEWAYS:
   Status: __
   Integrated Services: __ (target: Razorpay, PayU, PhonePe)
   Features: Insurance premium payment, booking deposits

2. MAPS & LOCATION:
   Status: __
   Provider: __ (Google Maps recommended)
   Features: Dealer/service center locator, route planning
   Performance: Load time __ seconds (target: <2s)

3. SMS/EMAIL SERVICE:
   Status: __
   Provider: __ (Twilio, SendGrid)
   Features: Alerts, notifications, OTP
   Deliverability: __ (target: 98%+)

4. IMAGE CDN:
   Status: __
   Provider: __ (CloudFront, Cloudflare, ImageKit)
   Purpose: Fast image delivery, optimization
   Coverage: Global (target: <200ms load)

5. ANALYTICS:
   Status: __
   Integrated: Google Analytics, Hotjar
   Tracking: User behavior, clicks, conversions
   Dashboard: YES/NO

6. SOCIAL MEDIA:
   Status: __
   Platforms: Facebook, Instagram, Twitter, YouTube
   Features: Share bikes, reviews, content feeds
   Integration: Social login, sharing buttons

7. FINANCE PARTNERS:
   Status: __
   Partners: Bike loan providers
   Features: Direct loan application, rate comparison
   Number of partners: __ (target: 5+)

8. INSURANCE PARTNERS:
   Status: __
   Partners: Insurance companies
   Features: Quote comparison, direct purchase
   Number of partners: __ (target: 5+)

9. VIDEO HOSTING:
   Status: __
   Platform: __ (YouTube, Vimeo, custom CDN)
   Quality: 1080p (target minimum)
   Streaming performance: __ ms (target: <500ms)

10. SEARCH ENGINE:
    Status: __
    Elasticsearch integration: YES/NO
    Real-time indexing: YES/NO
    Auto-complete: YES/NO
    Typo tolerance: YES/NO

11. CACHE MANAGEMENT:
    Status: __
    Redis cache: YES/NO
    Memcached: YES/NO
    Cache strategy documented: YES/NO
    Performance improvement: __ (target: 50%+ faster)

12. EMAIL MARKETING (Optional):
    Status: __
    Platform: __ (Mailchimp, Braze)
    Features: Newsletter, alerts, campaigns
    Subscriber count: __

13. REVIEW MODERATION:
    Status: __
    Auto-moderation system: YES/NO
    Manual review process: YES/NO
    Response time: __ hours (target: <24h)

14. BACKUP & DISASTER RECOVERY:
    Status: __
    Backup frequency: __ (target: daily)
    Recovery time objective: __ minutes
    Last successful recovery test: __

15. SECURITY IMPLEMENTATIONS:
    Status: __
    SSL Certificate: YES/NO
    HTTPS everywhere: YES/NO
    SQL Injection Protection: YES/NO
    XSS Protection: YES/NO
    Rate Limiting: YES/NO
    CSRF Tokens: YES/NO
    Regular Security Audits: YES/NO / Frequency: __
```

---

## PHASE 9: TESTING & QA CHECKLIST

### Instruction for Cursor:

```
TASK: Create comprehensive testing plan

FUNCTIONAL TESTING:

1. Search & Filter Functionality:
   - [ ] Budget filter works correctly
   - [ ] Brand filter works correctly
   - [ ] Type filter (Cruiser, Sport, etc.) works
   - [ ] CC range filter works
   - [ ] Multiple filters together work
   - [ ] Clear filters button works
   - [ ] Search autocomplete works
   - [ ] Typo tolerance works

2. Comparison Tool:
   - [ ] Can add bikes to comparison
   - [ ] Can compare 2-3 bikes correctly
   - [ ] Specifications display correctly
   - [ ] Price comparison accurate
   - [ ] Can remove bikes from comparison
   - [ ] Can export comparison (PDF/Email)
   - [ ] Can share comparison link

3. Calculators:
   - [ ] On-road price calculation accuracy
   - [ ] EMI calculation correct formula
   - [ ] Insurance premium estimates reasonable
   - [ ] Results update in real-time
   - [ ] Mobile display correct

4. Review System:
   - [ ] Can post review (authenticated user)
   - [ ] Can upload photos with review
   - [ ] Can rate bike (1-5 stars)
   - [ ] Can view other reviews
   - [ ] Can mark review helpful/unhelpful
   - [ ] Verified purchase badge displays
   - [ ] Reviews load efficiently

5. Used Bike Section:
   - [ ] Can browse used bikes
   - [ ] Can apply filters (year, mileage, price)
   - [ ] Can view seller details
   - [ ] Can contact seller
   - [ ] Valuation tool works accurately
   - [ ] Can list bike for sale
   - [ ] Photo uploads working

6. Dealer Locator:
   - [ ] Map loads correctly
   - [ ] Can search by location
   - [ ] Can filter by brand
   - [ ] Dealer info displays correctly
   - [ ] Can call dealer
   - [ ] Can get directions
   - [ ] Can book test drive

PERFORMANCE TESTING:

Load Time Targets:
- Home page: <2 seconds
- Listing page: <2.5 seconds
- Detail page: <2 seconds
- Calculator pages: <1.5 seconds
- Mobile: <3 seconds (slower networks)

Load Testing:
- [ ] Can handle 1000 concurrent users
- [ ] Can handle 100 requests/second
- [ ] Database queries optimized
- [ ] Images loading progressively
- [ ] No 404 errors under load

Browser Compatibility:
- [ ] Chrome (latest 2 versions)
- [ ] Firefox (latest 2 versions)
- [ ] Safari (latest 2 versions)
- [ ] Edge (latest 2 versions)
- [ ] Mobile Chrome/Safari

Mobile Testing:
- [ ] Responsive design all devices
- [ ] Touch interactions smooth
- [ ] Forms easy to use mobile
- [ ] Images scale correctly
- [ ] Portrait/landscape modes work
- [ ] Bottom navigation accessible

SECURITY TESTING:

- [ ] No SQL injection vulnerabilities
- [ ] No XSS vulnerabilities
- [ ] CSRF tokens implemented
- [ ] User authentication secure
- [ ] Password reset secure
- [ ] Sensitive data encrypted
- [ ] API endpoints authenticated
- [ ] Rate limiting working
- [ ] HTTPS enforced
- [ ] No hardcoded credentials

SEO TESTING:

- [ ] Meta descriptions present
- [ ] Meta titles optimized
- [ ] Structured data (Schema.org)
- [ ] Sitemap generated
- [ ] robots.txt configured
- [ ] Mobile-friendly test passes
- [ ] Page speed optimized
- [ ] Core Web Vitals: Good (target)

ACCESSIBILITY TESTING:

- [ ] WCAG 2.1 Level AA compliance
- [ ] Keyboard navigation works
- [ ] Screen reader compatible
- [ ] Color contrast sufficient
- [ ] Alt text for all images
- [ ] Form labels associated
- [ ] Focus indicators visible

CROSS-BROWSER CONSISTENCY:

Test these workflows in all browsers:
1. Browse bikes → Compare → Book test drive
2. Calculate on-road price → See dealer options
3. Post review → See it published
4. Search bike → Apply filters → Share
5. Sell bike → Upload photos → List

REGRESSION TESTING:

After each update:
- [ ] All previously working features still work
- [ ] No new bugs introduced
- [ ] Performance not degraded
- [ ] No broken links
- [ ] Forms still submit correctly

USER ACCEPTANCE TESTING (UAT):

Test with real users:
- [ ] Can complete buying journey
- [ ] Can complete selling journey
- [ ] Understand all features
- [ ] Navigation intuitive
- [ ] Search meets expectations
- [ ] Comparison helpful
- [ ] Review system trustworthy

TESTING REPORT TEMPLATE:
- Total test cases: __
- Passed: __
- Failed: __
- Blocked: __
- Critical issues: __
- Bug report links: __
```

---

## PHASE 10: PERFORMANCE & OPTIMIZATION

### Instruction for Cursor:

```
TASK: Optimize platform performance

FRONT-END OPTIMIZATION:

1. Image Optimization:
   - [ ] WebP format support
   - [ ] Lazy loading implemented
   - [ ] Responsive images (srcset)
   - [ ] Image compression (80-85% quality retained)
   - [ ] CDN delivery
   - [ ] Optimize for mobile (different sizes)
   - [ ] 360° viewer - optimized asset delivery

2. Code Splitting:
   - [ ] Route-based code splitting
   - [ ] Component lazy loading
   - [ ] Feature-based bundling
   - [ ] Remove unused dependencies
   - [ ] Tree-shaking enabled

3. Caching Strategy:
   - [ ] Service Worker implemented
   - [ ] Browser cache headers set
   - [ ] Cache busting strategy for updates
   - [ ] Static assets cached (images, CSS, JS)
   - [ ] API response caching (where applicable)

4. CSS/JS Optimization:
   - [ ] CSS minified
   - [ ] CSS unused declarations removed
   - [ ] JavaScript minified and uglified
   - [ ] No render-blocking resources
   - [ ] Critical CSS inlined

5. Font Optimization:
   - [ ] Limit font families (2-3 max)
   - [ ] Use system fonts where possible
   - [ ] Font subsetting
   - [ ] Async font loading
   - [ ] WOFF2 format

BACKEND OPTIMIZATION:

1. Database Optimization:
   - [ ] Proper indexing
   - [ ] Query optimization
   - [ ] Connection pooling
   - [ ] Read replicas for reports
   - [ ] Caching layer (Redis)

2. API Optimization:
   - [ ] Pagination for large datasets
   - [ ] Response compression (gzip)
   - [ ] Field selection (return only needed fields)
   - [ ] Rate limiting implemented
   - [ ] API versioning strategy

3. Server Optimization:
   - [ ] Gzip compression enabled
   - [ ] HTTP/2 enabled
   - [ ] Reverse proxy (Nginx)
   - [ ] Load balancing configured
   - [ ] Server-side caching

MONITORING & ALERTING:

- [ ] Uptime monitoring (99.9% target)
- [ ] Error rate monitoring
- [ ] Performance monitoring (Datadog, New Relic)
- [ ] Logs aggregation
- [ ] Alert thresholds configured
- [ ] Incident response plan

TARGET METRICS:

Core Web Vitals:
- Largest Contentful Paint (LCP): <2.5s
- First Input Delay (FID): <100ms
- Cumulative Layout Shift (CLS): <0.1

Lighthouse Scores:
- Performance: >90
- Accessibility: >95
- Best Practices: >90
- SEO: >90

Performance Budget:
- JS Bundle size: <150KB (gzipped)
- CSS size: <50KB (gzipped)
- Total page weight: <2MB (images included)
- Time to Interactive: <4s (mobile)
```

---

## QUICK START CHECKLIST

Use this when starting implementation work:

```
BEFORE STARTING CODE:
1. [ ] Run this full audit
2. [ ] Identify all missing features (use missing features matrix)
3. [ ] Prioritize by impact & complexity
4. [ ] Design unique approach for each feature
5. [ ] Create detailed technical specifications
6. [ ] Get design mockups reviewed
7. [ ] Estimate effort and resources

DURING DEVELOPMENT:
1. [ ] Follow component structure guidelines
2. [ ] Update database schema as needed
3. [ ] Create unit tests alongside code
4. [ ] Implement monitoring/logging
5. [ ] Optimize as you go (don't defer)
6. [ ] Keep documentation updated
7. [ ] Regular code reviews

BEFORE LAUNCH:
1. [ ] Complete all test phases
2. [ ] Security audit
3. [ ] Performance benchmarks met
4. [ ] SEO checklist passed
5. [ ] Accessibility tested
6. [ ] Load testing successful
7. [ ] Backup & disaster recovery tested
8. [ ] Monitoring & alerting configured
9. [ ] Team trained on systems
10. [ ] Rollback plan documented

AFTER LAUNCH:
1. [ ] Monitor error rates closely
2. [ ] Track user feedback
3. [ ] Monitor performance metrics
4. [ ] Plan quick fixes for issues
5. [ ] Collect user feedback systematically
6. [ ] Prioritize bugs vs features
7. [ ] Plan Phase 2 features
```

---

## FINAL NOTES FOR CURSOR

When implementing features, follow these principles:

**DESIGN UNIQUENESS:**
- Don't copy the exact UI from CarDekho or CarWale
- Adapt features for bike/motorcycle specificity
- Use bike enthusiast aesthetic (dark, dynamic, action-oriented)
- Include rider-centric features (seat height, handling, real mileage)
- Make it feel premium and modern

**USER EXPERIENCE:**
- Reduce friction in buying/selling journey
- Make calculations interactive and visual
- Provide immediate feedback on actions
- Mobile-first design approach
- Fast loading is critical (riders search on-the-go)

**CONTENT STRATEGY:**
- Rider stories over technical specs
- Community-generated content (real photos)
- Real-world experience over theoretical specs
- Lifestyle content alongside product info
- Regular fresh content (news, trends)

**DIFFERENTIATION:**
- Rider profile matching (unique)
- Real mileage database (crowdsourced)
- Maintenance cost calculator (detailed)
- Resale value predictor (helpful)
- Modification gallery (community-driven)
- Riding routes with bike suitability
- Combination of all these makes you unique

**DATA QUALITY:**
- Accurate pricing across all cities
- Complete specifications for every bike
- High-quality images (1080p minimum)
- Verified user reviews (moderated)
- Fresh content (daily updates minimum)
- Dealer data maintained (monthly refresh)

**PERFORMANCE CRITICAL:**
- Page loads in <2s
- Search results in <1s
- 360° viewer loads smoothly
- Mobile optimization essential
- CDN for all static assets
- Database queries optimized

GOOD LUCK WITH CARBIKDEKHO.COM!
The market needs a specialized, modern platform for Indian two-wheelers.
Make it unique, make it fast, make it helpful.
```

---

## APPENDIX: FEATURE PRIORITY MATRIX

High Priority + Low Complexity = Do First (Quick Wins):
- Advanced search filters
- On-road price calculator
- Bike comparison (2-3 bikes)
- EMI calculator
- Dealer locator
- Mobile responsive design

High Priority + High Complexity = Strategic Focus:
- 360° bike viewer
- User review system (with moderation)
- Used bike valuation
- Rider profile matcher
- Real mileage database

Medium Priority + Low Complexity = Next Phase:
- Accessories marketplace
- Maintenance cost calculator
- Price trend history
- Bike collections
- Photo gallery optimization

Low Priority + High Complexity = Future/Nice to Have:
- AR bike visualizer
- Riding routes database
- Modification gallery
- Community forum
- Advanced analytics dashboard

---

## END OF CURSOR PROMPT

This comprehensive prompt is designed to guide systematic implementation of CarBikeDekho.com.
Use it in Cursor to audit current state, identify gaps, and plan implementation with unique differentiation.

